TELKOMSEL LAUNCHER - ANDROID WEBVIEW PROJECT

Isi:
- app/src/main/assets/index.html : launcher HTML yang sudah disesuaikan
- Android WebView Native : membuka https://www.telkomsel.com/simpati di dalam aplikasi
- .github/workflows/build.yml : workflow GitHub Actions untuk membangun APK

Cara:
1. Upload seluruh isi ZIP ke repository GitHub (atau ekstrak lalu upload).
2. Buka tab Actions.
3. Jalankan workflow "Build Telkomsel Launcher APK".
4. Setelah selesai, unduh artifact "Telkomsel-Launcher-APK".

Catatan:
- Situs Telkomsel dimuat dalam Android WebView, bukan iframe dan bukan browser eksternal.
- Situs tertentu dapat memiliki kebijakan/fitur yang tidak sepenuhnya kompatibel dengan WebView.
- WhatsApp tetap membuka aplikasi WhatsApp melalui tautan wa.me.

ICON APLIKASI:
- Launcher memakai PNG ikon pengguna dengan background luar transparan.
- Menggunakan resource mipmap legacy agar bentuk artwork tidak diganti ikon kotak/bulat buatan.
- Tampilan akhir tetap dapat dipengaruhi launcher Android/perangkat.
